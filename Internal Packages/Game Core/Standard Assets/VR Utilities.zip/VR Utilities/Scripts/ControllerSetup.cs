﻿using UnityEngine;

using GameAnax.Core.Extension;
using GameAnax.Core.Utility;


public delegate void EnableDisableHeadReticle(bool isHeadTrackingOn);
public class ControllerSetup : MonoBehaviour {
	[SerializeField]
	private GameObject reporter;
	[SerializeField]
	private GameObject localAvatar;

	[SerializeField]
	private GameObject leftHand, rightHand, leftController, rightController;

	public static bool isHeadTrakingOn { private set; get; }
	public static bool IsOnTV = false;
	public static EnableDisableHeadReticle HeadTrackingStatusChanged;

	// Use this for initialization
	void Awake() {
		if(null != reporter) {
#if TEST
		reporter.SetActive(true);
#else
			reporter.SetActive(false);
#endif
		}
#if SHOW_VR_CONTROLLERS && VR_SUPPORTED
		localAvatar.SetActive(true);
		InvokeRepeating("CheckForControllers", 0f, 0.5f);
#endif
	}

#if VR_SUPPORTED
	private OVRInput.Controller _availControllers;
	void CheckForControllers() {
		if(IsOnTV) {
			//HeadTrackingStatusChanged.Invoke(false);
			return;
		}
		_availControllers = OVRInput.GetConnectedControllers();
		isHeadTrakingOn = !(((int)_availControllers).Contain((int)OVRInput.Controller.RTouch) || ((int)_availControllers).Contain((int)OVRInput.Controller.LTouch));

		if(null != leftHand) leftHand.SetActive(((int)_availControllers).Contain((int)OVRInput.Controller.LTouch));
		if(null != leftController) leftController.SetActive(((int)_availControllers).Contain((int)OVRInput.Controller.LTouch));

		if(null != rightHand) rightHand.SetActive(((int)_availControllers).Contain((int)OVRInput.Controller.RTouch));
		if(null != rightController) rightController.SetActive(((int)_availControllers).Contain((int)OVRInput.Controller.RTouch));

		if(null != HeadTrackingStatusChanged) HeadTrackingStatusChanged.Invoke(isHeadTrakingOn);
	}
#endif
}
