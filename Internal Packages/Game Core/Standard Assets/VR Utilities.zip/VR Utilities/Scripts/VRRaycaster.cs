using System;
using UnityEngine;


namespace VRStandardAssets.Utils {
	// In order to interact with objects in the scene
	// this class casts a ray into the scene and if it finds
	// a VRInteractiveItem it exposes it for other classes to use.
	// This script should be generally be placed on the camera.
	public class VRRaycaster :  MonoBehaviour{
		public static VRRaycaster Me;
		public event Action<RaycastHit> OnRaycasthit;                   // This event is called every frame that the user's gaze is over a collider.


		[SerializeField]
		private Transform rayStartPoint;
		[SerializeField]
		private LayerMask exclusionLayers;           // Layers to exclude from the raycast.
		[SerializeField]
		private Reticle reticle;                     // The reticle, if applicable.
		[SerializeField]
		private VRInput vrInput;                     // Used to call input based events on the current VRInteractiveItem.
		[SerializeField]
		private LineRenderer lineRenderer;
		[SerializeField]
		private bool showDebugRay;                   // Optionally show the debug ray.
		[SerializeField]
		private float debugRayLength = 5f;           // Debug ray length.
		[SerializeField]
		private float debugRayDuration = 1f;         // How long the Debug ray will remain visible.
		[SerializeField]
		private float rayLength = 500f;              // How far into the scene the ray is cast.

		private VRInteractiveItem _currentInteractible;                //The current interactive item
		private VRInteractiveItem _lastInteractible;                   //The last interactive item

		private bool IsEnableRaycast = true;

		// Utility for other classes to get the current interactive item
		public VRInteractiveItem currentInteractible {
			get { return _currentInteractible; }
		}

		void Awake() {
			Me = this;

		}
		
		
		private void OnEnable() {
			Me = this;
			ControllerSetup.HeadTrackingStatusChanged += EnableReticle;
			vrInput.OnClick += HandleClick;
			vrInput.OnDoubleClick += HandleDoubleClick;
			vrInput.OnUp += HandleUp;
			vrInput.OnDown += HandleDown;
		}


		private void OnDisable() {
			ControllerSetup.HeadTrackingStatusChanged -= EnableReticle;
			vrInput.OnClick -= HandleClick;
			vrInput.OnDoubleClick -= HandleDoubleClick;
			vrInput.OnUp -= HandleUp;
			vrInput.OnDown -= HandleDown;
		}
		public void EnableReticle(bool isHeadTrakingOn) {
			IsEnableRaycast = isHeadTrakingOn;
		}
		private void Update() {
			EyeRaycast();
		}

		private void EyeRaycast() {
			if (!IsEnableRaycast) return;
			// Show the debug ray if required
			if(showDebugRay) {
				Debug.DrawRay(rayStartPoint.position, rayStartPoint.forward * debugRayLength, Color.blue, debugRayDuration);
			}

			// Create a ray that points forwards from the camera.
			Ray ray = new Ray(rayStartPoint.position, rayStartPoint.forward);
			RaycastHit hit;

			// Do the raycast forweards to see if we hit an interactive item
			if(Physics.Raycast(ray, out hit, rayLength, ~exclusionLayers)) {
				VRInteractiveItem interactible = hit.collider.GetComponent<VRInteractiveItem>(); //attempt to get the VRInteractiveItem on the hit object
				_currentInteractible = interactible;

				// If we hit an interactive item and it's not the same as the last interactive item, then call Over
				if(interactible && interactible != _lastInteractible)
					interactible.Over();

				// Deactive the last interactive item 
				if(interactible != _lastInteractible)
					DeactiveLastInteractible();

				_lastInteractible = interactible;
				if(null != lineRenderer) {
					lineRenderer.SetPositions(new Vector3[] { rayStartPoint.position, hit.point });
				}
				// Something was hit, set at the hit position.
				if(reticle)
					reticle.SetPosition(hit);

				if(OnRaycasthit != null)
					OnRaycasthit(hit);

			} else {
				// Nothing was hit, deactive the last interactive item.
				DeactiveLastInteractible();
				_currentInteractible = null;

				// Position the reticle at default distance.
				if(reticle)
					reticle.SetPosition();
			}
		}

		public void ResetReticle() {
			DeactiveLastInteractible();
			_currentInteractible = null;

			// Position the reticle at default distance.
			if(reticle)
				reticle.SetPosition();
		}
		private void DeactiveLastInteractible() {
			if(_lastInteractible == null)
				return;

			_lastInteractible.Out();
			_lastInteractible = null;
		}


		private void HandleUp() {
			if(_currentInteractible != null)
				_currentInteractible.Up();
		}


		private void HandleDown() {
			if(_currentInteractible != null)
				_currentInteractible.Down();
		}


		private void HandleClick() {
			if(_currentInteractible != null)
				_currentInteractible.Click();
		}


		private void HandleDoubleClick() {
			if(_currentInteractible != null)
				_currentInteractible.DoubleClick();

		}
	}
}